CREATE OR REPLACE FUNCTION "public"."add_rating_history"("username" bpchar, "tcont" bpchar, "rating" int4)
  RETURNS "pg_catalog"."bool" AS $BODY$BEGIN
insert into ratinghistory
values ("username", "rating", "tcont", (select primarytitle from title_basics where title_basics.tconst = "tcont"));
return true;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100

--
CREATE OR REPLACE FUNCTION "public"."add_search_history"("username" bpchar, "search" bpchar)
  RETURNS "pg_catalog"."bool" AS $BODY$BEGIN

    INSERT INTO searchhistory (username,  mysearch)
    VALUES ("username", "search");

return true;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
--
CREATE OR REPLACE FUNCTION "public"."bookmark"("username" bpchar, "S" bpchar, "typ" bpchar)
  RETURNS "pg_catalog"."bool" AS $BODY$BEGIN
  CASE WHEN "typ" = 'movie' 
    THEN
        insert into bookmarked (username, tconst)
        values ("username", "S");
    ELSE
        insert into bookmarked (username, nconst)
        values ("username", "S");
END CASE;
return true;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100

--
CREATE OR REPLACE FUNCTION "public"."create_user"("usernam" bpchar, "pass" bpchar)
  RETURNS "pg_catalog"."bool" AS $BODY$BEGIN

IF EXISTS(select * from username where username.username = usernam)
THEN
    return false;
ELSE
    insert into username
    values (usernam, pass);
    return true;
END IF;
end
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100

--
CREATE OR REPLACE FUNCTION "public"."find_coplayers"("S" bpchar)
  RETURNS TABLE("primarynam" bpchar, "count" int8) AS $BODY$
BEGIN
create or replace view casting as 
select tconst,primarytitle,nconst,primaryname from title_basics
natural join title_principals natural join person;

return query select primaryname, count() from casting 
where tconst in (
    select tconst from title_principals 
    natural join person 
    where primaryname like 'Mads')
group by primaryname
order by count() desc limit 12;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
  ROWS 1000

--
CREATE OR REPLACE FUNCTION "public"."login"("usernam" bpchar, "pass" bpchar)
  RETURNS "pg_catalog"."bool" AS $BODY$BEGIN
CASE WHEN EXISTS (select * from username 
    where username.username = usernam and username.password = pass)
then 
    return true;
ELSE
    return false;
end case;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100

--
CREATE OR REPLACE FUNCTION "public"."name_rating"("S" bpchar)
RETURNS "pg_catalog"."int4" AS $BODY$
declare tab int;
BEGIN
select sum(averagerating*numvotes)/sum(numvotes) into tab from casting 
natural join title_ratings 
where primaryname="S";
return tab;
END
$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

--
CREATE OR REPLACE FUNCTION "public"."name_search"("username" bpchar, "S" bpchar)
  RETURNS TABLE("nconst" bpchar, "primaryname" bpchar) AS $BODY$BEGIN
PERFORM add_search_history(username, "S");

return query select person.nconst, person.primaryname from person
where person.primaryname like '%'||"S"||'%';
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
  ROWS 1000

--
CREATE OR REPLACE FUNCTION "public"."popular_actors"("amount" int4)
  RETURNS TABLE("primaryname" bpchar, "rating" numeric) AS $BODY$BEGIN
return query select casting.primaryname, sum(averagerating*numvotes)/sum(numvotes) from casting
natural join title_ratings
group by casting.primaryname
limit "amount";
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
  ROWS 1000

--
CREATE OR REPLACE FUNCTION "public"."popular_actors"("S" bpchar, "amount" int4)
RETURNS TABLE("primaryname" bpchar, "rating" numeric) AS $BODY$BEGIN
return query select casting.primaryname, sum(averagerating*numvotes)/sum(numvotes) from casting
natural join title_ratings
group by casting.primaryname
limit "amount";
END
$BODY$
LANGUAGE plpgsql VOLATILE
COST 100
ROWS 1000

--
CREATE OR REPLACE FUNCTION "public"."rate"("username" bpchar, "tit" bpchar, "rat" int4)
  RETURNS "pg_catalog"."bool" AS $BODY$BEGIN
perform add_rating_history("username", "tit", "rat");

update title_ratings
set averagerating = ((averagerating * numvotes) + "rat") / (numvotes+1), numvotes = numvotes+1
where tconst = tit;

return true;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100

--
CREATE OR REPLACE FUNCTION "public"."string_search"("username" bpchar, "S" bpchar)
  RETURNS TABLE("tconst" bpchar, "primarytitle" text, "startyear" bpchar) AS $BODY$ BEGIN
perform add_search_history("username", "S");

return query select title_basics.tconst, title_basics.primarytitle, title_basics.startyear from title_basics
inner join omdb_data on omdb_data.tconst = title_basics.tconst
where title_basics.primarytitle like '%'||"S"||'%' OR plot like '%'||"S"||'%';
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100
  ROWS 1000

--
--CREATE OR REPLACE FUNCTION "public"."structured_string_search"("username" bpchar, "tit" bpchar, ---"plo" bpchar, "cha" bpchar, "per" bpchar)
 -- RETURNS TABLE("tconst" bpchar, "primarytitle" bpchar) AS $BODY$BEGIN
--perform add_search_history("username", false, "tit", "plo", "cha", "per");

--return query select distinct title.tconst, primarytitle from title_basics
--inner join omdb_data on omdb_data.tconst = title_basics.tconst
--inner join titleprincipals on titleprincipals.tconst = title_basics.tconst
--inner join person on titleprincipals.nconst = person.nconst
--where primarytitle like lower('%'||"tit"||'%') AND plot like lower('%'||"plo"||'%') 
--AND titleprincipals.characters like lower('%'||"cha"||'%') AND primaryname like lower('%'||"per"||'%');
--END
--$BODY$
  --LANGUAGE plpgsql VOLATILE
  --COST 100
  --ROWS 1000

