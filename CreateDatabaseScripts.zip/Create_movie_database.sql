DROP TABLE IF EXISTS name_temp;
CREATE TABLE name_temp (LIKE name_basics);

-- step 2
INSERT INTO name_temp (nconst, primaryname, birthyear, deathyear, primaryprofession, knownfortitles)
SELECT 
    DISTINCT ON (nconst) nconst,
		primaryname,
    birthyear, 
		deathyear, 
		primaryprofession, 
		knownfortitles
FROM name_basics; 

-- step 3
DROP TABLE name_basics;

-- step 4
ALTER TABLE name_temp
RENAME TO name_basics;             

DROP TABLE IF EXISTS genre;
CREATE TABLE genre (
	tconst CHAR(50),
	name  CHAR(50)
);

--ALTER table searchhistory
--DROP COLUMN simplesearch, 
--DROP COLUMN title, 
--DROP COLUMN plot, 
--DROP COLUMN actor;

--ALTER table searchhistory
--RENAME COLUMN character to mysearch;

--
INSERT INTO genre ( name, tconst)
SELECT unnest(string_to_array(genres, ',')) as name, tconst
FROM title_basics;


ALTER TABLE title_basics
DROP COLUMN genres;


DROP TABLE IF EXISTS types;
CREATE TABLE types (
	tconst CHAR(10),
	ordering int4, 
	type  varchar(256)
);

INSERT INTO types (tconst, ordering, type)
SELECT titleid, ordering, types
FROM title_akas;

ALTER table title_akas
DROP COLUMN types;

ALTER table title_akas
RENAME COLUMN titleid TO tconst;


DROP TABLE IF EXISTS person;
CREATE  TABLE person (
	nconst CHAR(50),
	primaryname  CHAR(50),
	birthyear char(4) ,
	deathyear char(4)
	);
	
INSERT INTO person (nconst, primaryname, birthyear, deathyear)
SELECT nconst, primaryname, birthyear, deathyear 
FROM name_basics;



DROP TABLE IF EXISTS primaryprofession;
CREATE  TABLE primaryprofession (
	nconst CHAR(50),
	profession varchar(256)
	);
	
INSERT INTO primaryprofession (profession, nconst)
SELECT unnest(string_to_array(primaryprofession, ',')) as profession, nconst
--SELECT nconst, primaryprofession
FROM name_basics;

DROP TABLE IF EXISTS knownfortitle;
CREATE  TABLE knownfortitle (
	tconst varchar(256),
	nconst CHAR(50)
	);
	
INSERT INTO knownfortitle (tconst, nconst)
SELECT unnest(string_to_array(knownfortitles, ',')) as tconst, nconst 
FROM name_basics;

-- KEYS
ALTER TABLE title_basics
ADD PRIMARY key (tconst);

--
ALTER TABLE person
ADD PRIMARY key (nconst);

--
ALTER TABLE title_akas
ADD FOREIGN KEY (tconst) REFERENCES title_basics(tconst);

--
ALTER TABLE title_episode
ADD FOREIGN KEY (parenttconst) REFERENCES title_basics(tconst);

--
ALTER TABLE title_ratings
ADD FOREIGN KEY (tconst) REFERENCES title_basics(tconst);

--
ALTER TABLE types
ADD FOREIGN KEY (tconst) REFERENCES title_basics(tconst);

--ALTER TABLE types
--ADD FOREIGN KEY (ordering) REFERENCES title_akas(ordering);

--
ALTER TABLE primaryprofession
ADD FOREIGN KEY (nconst) REFERENCES person(nconst);

--
ALTER TABLE knownfortitle
ADD FOREIGN KEY (nconst) REFERENCES person(nconst);

--ALTER TABLE knownfortitle
--ADD FOREIGN KEY (tconst) REFERENCES title_basics(tconst);

--
ALTER TABLE title_principals
ADD FOREIGN KEY (tconst) REFERENCES title_basics(tconst);

--ALTER TABLE title_principals
--ADD FOREIGN KEY (nconst) REFERENCES person(nconst);

DROP TABLE name_basics;

create or replace view casting as 
    select tconst,primarytitle,nconst,primaryname from title_basics
    natural join title_principals natural join person;
