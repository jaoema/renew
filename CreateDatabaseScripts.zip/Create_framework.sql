CREATE TABLE username (
username CHAR(50) PRIMARY KEY,
password CHAR(50)
);

SELECT * FROM create_user('hans1', 'grethe')


CREATE TABLE searchhistory (
username CHAR(50),
mysearch CHAR(50)
);

ALTER TABLE searchhistory
ADD FOREIGN KEY (username) REFERENCES username(username);


CREATE TABLE ratinghistory (
username CHAR(50) ,
rating int2,
tconst CHAR(10),
title CHAR(50)
);

ALTER TABLE ratinghistory
ADD FOREIGN KEY (username) REFERENCES username(username);
ALTER TABLE ratinghistory
ADD FOREIGN KEY (tconst) REFERENCES title_basics(tconst);

DROP TABLE IF EXISTS bookmarked;
CREATE TABLE bookmarked (
username CHAR(50) ,
tconst CHAR(10), 
nconst CHAR(50) 
);

ALTER TABLE bookmarked
ADD FOREIGN KEY (username) REFERENCES username(username);
ALTER TABLE bookmarked
ADD FOREIGN KEY (tconst) REFERENCES title_basics(tconst);
ALTER TABLE bookmarked
ADD FOREIGN KEY (nconst) REFERENCES person(nconst);

